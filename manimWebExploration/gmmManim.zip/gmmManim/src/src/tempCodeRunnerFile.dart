 if ((exponent2) > 1e1) {
        print(exponent2);
        print("dkalfdksldf");
        exponent2 = 1e1;
        print(exponent2);
    }