
// Future animateData1D(List<Dot> dots, List<Dot> dots2) async {
//   // await playMany([
//   //   for (var i = 0; i < dots.length; i++) Transform(dots[i], target: dots2[i])
//   // ]);
//   await play(Transform(dots, target: dots2))
// }
